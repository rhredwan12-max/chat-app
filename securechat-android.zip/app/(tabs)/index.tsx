import { useMemo, useState } from "react";
import { FlatList, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useRouter } from "expo-router";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

type Conversation = { id: string; name: string; preview: string; time: string; unread: number; online: boolean; group?: boolean };

const initialConversations: Conversation[] = [
  { id: "nabila", name: "Nabila Rahman", preview: "The photos are ready.", time: "10:42", unread: 2, online: true },
  { id: "design-team", name: "Design Team", preview: "Arif: New mockups uploaded", time: "09:18", unread: 5, online: false, group: true },
  { id: "tanvir", name: "Tanvir Ahmed", preview: "See you tomorrow", time: "Yesterday", unread: 0, online: false },
  { id: "family", name: "Family Circle", preview: "Mom: Dinner at 8", time: "Tue", unread: 0, online: false, group: true },
];

export default function ConversationsScreen() {
  const colors = useColors();
  const router = useRouter();
  const [query, setQuery] = useState("");
  const [conversations] = useState(initialConversations);
  const filtered = useMemo(() => conversations.filter((item) => item.name.toLowerCase().includes(query.toLowerCase())), [conversations, query]);

  return (
    <ScreenContainer edges={["top", "left", "right"]} containerClassName="bg-background">
      <View style={styles.container}>
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>SECURECHAT</Text>
            <Text style={[styles.title, { color: colors.foreground }]}>Messages</Text>
          </View>
          <Pressable onPress={() => router.push("/settings")} style={({ pressed }) => [styles.iconButton, { backgroundColor: colors.surface }, pressed && styles.pressed]} accessibilityLabel="Open settings">
            <MaterialIcons name="security" size={22} color={colors.primary} />
          </Pressable>
        </View>

        <View style={[styles.search, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <MaterialIcons name="search" size={21} color={colors.muted} />
          <TextInput value={query} onChangeText={setQuery} placeholder="Search conversations" placeholderTextColor={colors.muted} style={[styles.searchInput, { color: colors.foreground }]} returnKeyType="search" />
        </View>

        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Recent chats</Text>
          <Pressable onPress={() => router.push("/new-conversation")} style={({ pressed }) => [pressed && styles.pressed]}>
            <Text style={[styles.newText, { color: colors.primary }]}>New chat</Text>
          </Pressable>
        </View>

        <FlatList
          data={filtered}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          showsVerticalScrollIndicator={false}
          initialNumToRender={6}
          maxToRenderPerBatch={6}
          windowSize={5}
          removeClippedSubviews={Platform.OS === "android"}
          renderItem={({ item }) => (
            <Pressable onPress={() => router.push({ pathname: "/chat/[id]", params: { id: item.id, name: item.name, group: item.group ? "true" : "false" } })} style={({ pressed }) => [styles.row, pressed && styles.rowPressed]}>
              <View style={[styles.avatar, { backgroundColor: item.group ? colors.primary : colors.surface, borderColor: colors.border }]}>
                <MaterialIcons name={item.group ? "groups" : "person"} size={24} color={item.group ? "#FFFFFF" : colors.primary} />
                {item.online && <View style={[styles.onlineDot, { backgroundColor: colors.success, borderColor: colors.background }]} />}
              </View>
              <View style={styles.rowContent}>
                <View style={styles.rowTop}>
                  <Text style={[styles.name, { color: colors.foreground }]} numberOfLines={1}>{item.name}</Text>
                  <Text style={[styles.time, { color: colors.muted }]}>{item.time}</Text>
                </View>
                <View style={styles.rowBottom}>
                  <Text style={[styles.preview, { color: colors.muted }]} numberOfLines={1}>{item.preview}</Text>
                  {item.unread > 0 && <View style={[styles.badge, { backgroundColor: colors.primary }]}><Text style={styles.badgeText}>{item.unread}</Text></View>}
                </View>
              </View>
            </Pressable>
          )}
          ListEmptyComponent={<Text style={[styles.empty, { color: colors.muted }]}>No conversations found.</Text>}
        />

        <Pressable onPress={() => router.push("/new-conversation")} style={({ pressed }) => [styles.fab, { backgroundColor: colors.primary }, pressed && styles.fabPressed]} accessibilityLabel="Start a new conversation">
          <MaterialIcons name="edit" size={23} color="#FFFFFF" />
        </Pressable>
      </View>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 20 },
  header: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", paddingTop: 10, paddingBottom: 22 },
  eyebrow: { fontSize: 11, letterSpacing: 2, fontWeight: "800", marginBottom: 4 },
  title: { fontSize: 31, lineHeight: 38, fontWeight: "800" },
  iconButton: { width: 44, height: 44, borderRadius: 15, alignItems: "center", justifyContent: "center" },
  search: { height: 48, borderWidth: 1, borderRadius: 15, flexDirection: "row", alignItems: "center", paddingHorizontal: 14, gap: 9 },
  searchInput: { flex: 1, fontSize: 15, paddingVertical: 0 },
  sectionHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 28, marginBottom: 12 },
  sectionTitle: { fontSize: 16, fontWeight: "700" },
  newText: { fontSize: 14, fontWeight: "700" },
  list: { paddingBottom: 110 },
  row: { flexDirection: "row", alignItems: "center", paddingVertical: 13, gap: 13 },
  rowPressed: { opacity: 0.65 },
  avatar: { width: 53, height: 53, borderRadius: 19, borderWidth: 1, alignItems: "center", justifyContent: "center", position: "relative" },
  onlineDot: { position: "absolute", right: -1, bottom: -1, width: 14, height: 14, borderRadius: 7, borderWidth: 2 },
  rowContent: { flex: 1, gap: 5 },
  rowTop: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 8 },
  rowBottom: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 8 },
  name: { fontSize: 16, fontWeight: "700", flex: 1 },
  time: { fontSize: 12 },
  preview: { fontSize: 13, flex: 1 },
  badge: { minWidth: 21, height: 21, borderRadius: 11, alignItems: "center", justifyContent: "center", paddingHorizontal: 6 },
  badgeText: { color: "#FFFFFF", fontSize: 11, fontWeight: "800" },
  empty: { textAlign: "center", marginTop: 40 },
  fab: { position: "absolute", right: 2, bottom: 24, width: 58, height: 58, borderRadius: 20, alignItems: "center", justifyContent: "center", elevation: 4, shadowColor: "#000", shadowOpacity: 0.18, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } },
  fabPressed: { transform: [{ scale: 0.96 }], opacity: 0.9 },
  pressed: { opacity: 0.65 },
});
