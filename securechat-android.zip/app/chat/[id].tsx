import { useMemo, useState } from "react";
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

type Message = { id: string; text: string; mine: boolean; time: string; status?: string; reply?: string };

export default function ChatScreen() {
  const colors = useColors();
  const router = useRouter();
  const params = useLocalSearchParams<{ name?: string; group?: string }>();
  const name = params.name ?? "New conversation";
  const isGroup = params.group === "true";
  const [draft, setDraft] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    { id: "1", text: "Hey! This chat is protected.", mine: false, time: "10:34" },
    { id: "2", text: "Nice. I like the security-first approach.", mine: true, time: "10:35", status: "Read" },
    { id: "3", text: "The photos are ready.", mine: false, time: "10:42" },
  ]);
  const subtitle = useMemo(() => (isGroup ? "8 members" : "Online now"), [isGroup]);

  const sendMessage = () => {
    const text = draft.trim();
    if (!text) return;
    setMessages((current) => [...current, { id: Date.now().toString(), text, mine: true, time: "Now", status: "Sent" }]);
    setDraft("");
  };

  return (
    <ScreenContainer edges={["top", "left", "right", "bottom"]}>
      <KeyboardAvoidingView style={styles.screen} behavior={Platform.OS === "ios" ? "padding" : undefined} keyboardVerticalOffset={8}>
        <View style={[styles.header, { borderBottomColor: colors.border }]}>
          <Pressable onPress={() => router.back()} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]} accessibilityLabel="Go back"><MaterialIcons name="arrow-back" size={23} color={colors.foreground} /></Pressable>
          <View style={styles.headerIdentity}>
            <View style={[styles.smallAvatar, { backgroundColor: isGroup ? colors.primary : colors.surface }]}><MaterialIcons name={isGroup ? "groups" : "person"} size={21} color={isGroup ? "#FFFFFF" : colors.primary} /></View>
            <View><Text style={[styles.headerName, { color: colors.foreground }]} numberOfLines={1}>{name}</Text><Text style={[styles.headerSub, { color: isGroup ? colors.muted : colors.success }]}>{subtitle}</Text></View>
          </View>
          <Pressable onPress={() => router.push("/security-center")} style={({ pressed }) => [styles.headerButton, pressed && styles.pressed]} accessibilityLabel="Open security details"><MaterialIcons name="verified-user" size={22} color={colors.primary} /></Pressable>
        </View>

        <View style={[styles.encryptionBanner, { backgroundColor: colors.surface }]}><MaterialIcons name="lock" size={14} color={colors.primary} /><Text style={[styles.encryptionText, { color: colors.muted }]}>Messages are private on this device</Text></View>

        <FlatList data={messages} keyExtractor={(item) => item.id} contentContainerStyle={styles.messages} showsVerticalScrollIndicator={false} renderItem={({ item }) => (
          <View style={[styles.messageLine, item.mine ? styles.mineLine : styles.theirLine]}>
            <View style={[styles.bubble, item.mine ? { backgroundColor: colors.primary } : { backgroundColor: colors.surface, borderColor: colors.border, borderWidth: 1 }]}>
              {item.reply && <Text style={[styles.reply, { color: item.mine ? "#D8F7FA" : colors.primary }]}>{item.reply}</Text>}
              <Text style={[styles.messageText, { color: item.mine ? "#FFFFFF" : colors.foreground }]}>{item.text}</Text>
              <View style={styles.meta}><Text style={[styles.metaText, { color: item.mine ? "#D8F7FA" : colors.muted }]}>{item.time}</Text>{item.mine && <Text style={[styles.metaText, { color: "#D8F7FA" }]}>{item.status === "Read" ? "✓✓" : "✓"}</Text>}</View>
            </View>
          </View>
        )} />

        <View style={styles.composerRow}>
          <Pressable onPress={() => router.push("/attachments")} style={({ pressed }) => [styles.actionButton, { backgroundColor: colors.surface }, pressed && styles.pressed]} accessibilityLabel="Add attachment"><MaterialIcons name="add" size={23} color={colors.primary} /></Pressable>
          <View style={[styles.composer, { backgroundColor: colors.surface, borderColor: colors.border }]}><TextInput value={draft} onChangeText={setDraft} placeholder="Write a message" placeholderTextColor={colors.muted} style={[styles.input, { color: colors.foreground }]} multiline maxLength={1000} /><Pressable onPress={() => setDraft((value) => `${value} 🙂`)} style={({ pressed }) => [pressed && styles.pressed]} accessibilityLabel="Add reaction"><MaterialIcons name="mood" size={21} color={colors.muted} /></Pressable></View>
          <Pressable onPress={sendMessage} style={({ pressed }) => [styles.sendButton, { backgroundColor: draft.trim() ? colors.primary : colors.border }, pressed && styles.sendPressed]} accessibilityLabel="Send message"><MaterialIcons name="send" size={20} color="#FFFFFF" /></Pressable>
        </View>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({ screen: { flex: 1 }, header: { minHeight: 66, borderBottomWidth: StyleSheet.hairlineWidth, flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 7 }, headerButton: { width: 42, height: 42, alignItems: "center", justifyContent: "center" }, headerIdentity: { flex: 1, flexDirection: "row", alignItems: "center", gap: 10 }, smallAvatar: { width: 40, height: 40, borderRadius: 14, alignItems: "center", justifyContent: "center" }, headerName: { fontSize: 16, lineHeight: 20, fontWeight: "700", maxWidth: 230 }, headerSub: { fontSize: 12, marginTop: 2 }, encryptionBanner: { flexDirection: "row", alignItems: "center", gap: 6, alignSelf: "center", borderRadius: 20, paddingHorizontal: 12, paddingVertical: 7, marginTop: 12 }, encryptionText: { fontSize: 11 }, messages: { paddingHorizontal: 14, paddingVertical: 18, gap: 10, flexGrow: 1, justifyContent: "flex-end" }, messageLine: { width: "100%", flexDirection: "row" }, mineLine: { justifyContent: "flex-end" }, theirLine: { justifyContent: "flex-start" }, bubble: { maxWidth: "80%", borderRadius: 18, paddingHorizontal: 14, paddingTop: 10, paddingBottom: 7 }, messageText: { fontSize: 15, lineHeight: 21 }, meta: { flexDirection: "row", justifyContent: "flex-end", gap: 5, marginTop: 4 }, metaText: { fontSize: 10 }, reply: { fontSize: 11, fontWeight: "700", marginBottom: 4 }, composerRow: { flexDirection: "row", alignItems: "flex-end", gap: 8, paddingHorizontal: 10, paddingTop: 8, paddingBottom: 6 }, actionButton: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, composer: { flex: 1, minHeight: 42, maxHeight: 120, borderRadius: 15, borderWidth: 1, flexDirection: "row", alignItems: "flex-end", paddingLeft: 13, paddingRight: 10, paddingVertical: 8 }, input: { flex: 1, fontSize: 15, maxHeight: 98, padding: 0 }, sendButton: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, sendPressed: { transform: [{ scale: 0.95 }] }, pressed: { opacity: 0.65 }, });
