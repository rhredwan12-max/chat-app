import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { useRouter } from "expo-router";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";

const contacts = [
  { id: "nabila", name: "Nabila Rahman", handle: "@nabila", icon: "person" as const },
  { id: "tanvir", name: "Tanvir Ahmed", handle: "@tanvir", icon: "person" as const },
  { id: "sadia", name: "Sadia Khan", handle: "@sadia", icon: "person" as const },
];

export default function NewConversationScreen() {
  const colors = useColors();
  const router = useRouter();
  return <ScreenContainer edges={["top", "left", "right"]}><View style={styles.container}>
    <View style={styles.header}><Pressable onPress={() => router.back()} style={styles.back}><MaterialIcons name="arrow-back" size={23} color={colors.foreground} /></Pressable><Text style={[styles.title, { color: colors.foreground }]}>New conversation</Text><View style={styles.back} /></View>
    <Text style={[styles.helper, { color: colors.muted }]}>Choose a contact to start a private chat.</Text>
    <Pressable onPress={() => router.push("/new-group")} style={({ pressed }) => [styles.groupButton, { backgroundColor: colors.surface }, pressed && styles.pressed]}><View style={[styles.groupIcon, { backgroundColor: colors.primary }]}><MaterialIcons name="groups" size={22} color="#FFFFFF" /></View><Text style={[styles.groupText, { color: colors.foreground }]}>Create a new group</Text><MaterialIcons name="chevron-right" size={22} color={colors.muted} /></Pressable>
    <Text style={[styles.section, { color: colors.foreground }]}>Contacts</Text>
    <FlatList data={contacts} keyExtractor={(item) => item.id} renderItem={({ item }) => <Pressable onPress={() => router.push({ pathname: "/chat/[id]", params: { id: item.id, name: item.name } })} style={({ pressed }) => [styles.row, pressed && styles.pressed]}><View style={[styles.avatar, { backgroundColor: colors.surface }]}><MaterialIcons name={item.icon} size={23} color={colors.primary} /></View><View><Text style={[styles.name, { color: colors.foreground }]}>{item.name}</Text><Text style={[styles.handle, { color: colors.muted }]}>{item.handle}</Text></View></Pressable>} />
  </View></ScreenContainer>;
}
const styles = StyleSheet.create({ container: { flex: 1, paddingHorizontal: 20 }, header: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingVertical: 12 }, back: { width: 42, height: 42, alignItems: "center", justifyContent: "center" }, title: { fontSize: 18, fontWeight: "700" }, helper: { fontSize: 14, lineHeight: 20, marginTop: 12, marginBottom: 24 }, groupButton: { borderRadius: 17, padding: 13, flexDirection: "row", alignItems: "center", gap: 12 }, groupIcon: { width: 42, height: 42, borderRadius: 14, alignItems: "center", justifyContent: "center" }, groupText: { flex: 1, fontSize: 15, fontWeight: "700" }, section: { fontSize: 15, fontWeight: "700", marginTop: 30, marginBottom: 8 }, row: { flexDirection: "row", alignItems: "center", gap: 13, paddingVertical: 12 }, avatar: { width: 48, height: 48, borderRadius: 16, alignItems: "center", justifyContent: "center" }, name: { fontSize: 15, fontWeight: "700" }, handle: { fontSize: 13, marginTop: 3 }, pressed: { opacity: 0.65 } });
