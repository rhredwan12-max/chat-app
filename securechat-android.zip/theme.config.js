/** @type {const} */
const themeColors = {
  primary: { light: '#118DAA', dark: '#26C6DA' },
  background: { light: '#FFFFFF', dark: '#0B1220' },
  surface: { light: '#F4F8FB', dark: '#131D2E' },
  foreground: { light: '#0F172A', dark: '#F4F8FB' },
  muted: { light: '#64748B', dark: '#9BA1A6' },
  border: { light: '#E5E7EB', dark: '#334155' },
  success: { light: '#22C55E', dark: '#4ADE80' },
  warning: { light: '#F59E0B', dark: '#FBBF24' },
  error: { light: '#EF4444', dark: '#F87171' },
};

module.exports = { themeColors };
